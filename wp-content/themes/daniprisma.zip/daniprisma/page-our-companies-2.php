<?php get_header();?>

<?php /* Template Name: Our Companies Detail Template */ ?>
<?php
  $detailCompanies = get_field('column_top');  ?>
  <section id="our-companies-page" class="pb-100vh" style="background-image: url(<?php echo esc_url( $detailCompanies['img_background']['url'] ); ?>)">
    <div class="text-column w-90" data-aos="fade-up">
      <div class="row">
        <div class="col-md-6 text-uppercase">
          <h4 class="mb-0 text-white"><?php the_title();?></h4>
          <div class="title text-white "><?php echo $detailCompanies['headline']; ?></div>
        </div>
        <div class="col-md-6">
          <div class="list-img">
            <div class="img1"><img src="<?php echo esc_url( $detailCompanies['img_1']['url'] ); ?>" alt="" class="img-fluid"></div>
            <div class="row mt-4 justify-content-between">
              <div class="img2 col-md-5"><img src="<?php echo esc_url( $detailCompanies['img_2']['url'] ); ?>" alt="" class="img-fluid"></div>
              <div class="img3 col-md-7"><img src="<?php echo esc_url( $detailCompanies['img_3']['url'] ); ?>" alt="" class="img-fluid"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php
  $detailCompanies2 = get_field('column_bottom');  ?>
  <section id="our-companies-content-page" class="section pb-0">
    <div class="container pb-5" data-aos="fade-up">
      <div class="row justify-content-center pb-5 mb-5">
        <div class="col-md-6">
          <div class="col-left ">
            <h4 class="mb-0 text-uppercase"><?php the_title();?></h4>
            <div class="title-col text-uppercase"><?php echo $detailCompanies2['headline']; ?></div>
            <div class="shortdesc"><?php the_content();?></div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="img1"><img src="<?php echo esc_url( $detailCompanies2['img_1']['url'] ); ?>" alt="" class="img-fluid"></div>
          <div class="row mt-4 justify-content-between">
            <div class="img2 col-md-5"><img src="<?php echo esc_url( $detailCompanies2['img_2']['url'] ); ?>" alt="" class="img-fluid"></div>
            <div class="img3 col-md-7"><img src="<?php echo esc_url( $detailCompanies2['img_3']['url'] ); ?>" alt="" class="img-fluid"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
    
<?php get_footer();?>  