<?php get_header();?>

<?php /* Template Name: our companies Template */ ?>
<?php
  $ourCompanies = get_field('our_companies');  ?>
  <section id="our-companies-page" style="background-image: url(<?php echo esc_url( $ourCompanies['img']['url'] ); ?>)">
    <div class="text-column" data-aos="fade-up">
      <h1 class="title text-white text-uppercase"><?php echo $ourCompanies['title']; ?></h1>
    </div>
  </section>
  <section id="our-companies-content-page" class="section p-0">
    <div class="container">
        <div class="py-4">
            <h1 class="text-uppercase title-cat"><?php echo $ourCompanies['title_section']; ?></h1>
        </div>
    </div>  
    <div class="content-our-companies" data-aos="fade-up">
      <div class="row">
      <?php 
        $menusCompanies = get_field('menu_companies');
        if( $menusCompanies ) {
          foreach( $menusCompanies as $menusCompaniesx ) { 
      ?> 
        <div class="block col-md-6 px-0">
          <div class="img"><img src="<?php echo esc_url( $menusCompaniesx['img']['url'] ); ?>" alt="" class="img-fluid"></div>
          <div class="title"><a href="<?php echo $menusCompaniesx['url']; ?>" class="text-uppercase"><?php echo $menusCompaniesx['menus']; ?></a></div>
        </div>
      <?php 
            } 
          }
        ?>
      </div>
    </div>
  </section>
    
<?php get_footer();?>  