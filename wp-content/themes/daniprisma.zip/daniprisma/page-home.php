<?php get_header();?>
<?php /* Template Name: Home Template */ ?>

  <!-- ======= Hero Section ======= -->
  <?php
  $home1 = get_field('home_headline_group');  ?>
  <section id="hero" class="hero">
    <div class="img">
      <img src="<?php echo esc_url( $home1['img']['url'] ); ?>" alt="" class="img-fluid">
    </div>
    <div class="info d-flex align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6 text-center">
            <h2 data-aos="fade-down"><span><?php echo $home1['headline']; ?></span><br/><?php echo $home1['sub_headline']; ?></h2>
            <p data-aos="fade-up"><?php echo $home1['description']; ?></p>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Hero Section -->
  <?php
  $about1 = get_field('about_us_section');  ?>
  <section id="get-started" class="about get-started section-bg" >
    <div class="position-relative">
      <div class="container">
        <div class="row justify-content-between gy-4">

          <div class="col-lg-4 d-flex align-items-start mt-5 mt-sm-0" data-aos="fade-up">
            <div class="content">
              <h3 class="text-light text-uppercase"><?php echo $about1['title_section']; ?>  </h3>
            </div>
          </div>

          <div class="col-lg-8 mt-0 mt-sm-2" data-aos="fade">
            <p>
            <?php echo $about1['description']; ?>  
            </p>
          
            <div class="stats-counter row">

              <div class="col-lg-3 col-md-6">
                <div class="stats-item d-flex align-items-center w-100 h-100">
                  <div>
                    <span data-purecounter-start="0" data-purecounter-end="250" data-purecounter-duration="1" class="purecounter"></span>
                    <p><?php echo $about1['csr']; ?></p>
                  </div>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-md-6">
                <div class="stats-item d-flex align-items-center w-100 h-100">
                  <div>
                    <span data-purecounter-start="0" data-purecounter-end="2500" data-purecounter-duration="1" class="purecounter"></span>
                    <p><?php echo $about1['staff']; ?></p>
                  </div>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-md-6">
                <div class="stats-item d-flex align-items-center w-100 h-100">
                  <div>
                    <span data-purecounter-start="0" data-purecounter-end="30" data-purecounter-duration="1" class="purecounter"></span>
                    <p><?php echo $about1['subsidiaris']; ?></p>
                  </div>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-md-6">
                <div class="stats-item d-flex align-items-end p-0 w-100 h-100">
                  <div>
                    <p><a href="#">BOD & DOC</a></p>
                  </div>
                </div>
              </div><!-- End Stats Item -->

            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  
  <section id="constructions" class="constructions">
    <div class="header-panel">
      <div class="container">
      <?php
  $milestoneSection = get_field('milestone_title_section');  ?>
        <h1 class="text-uppercase title-panel"><?php echo $milestoneSection['title_section']; ?></h1>
      </div>
    </div>
    <div class="container py-5" data-aos="fade-up">

      <div class="section-padding">
        <div class="screenshot_slider owl-carousel owl-theme">
        <?php 
          $a = 1;
          $milestoneHome = get_field('milestone');
          if( $milestoneHome ) {
            foreach( $milestoneHome as $milestoneHomex ) { 
            ?> 
          <div class="item" data-hash="data-<?php echo $a++;?>">
            <img src="<?php echo esc_url( $milestoneHomex['img']['url'] ); ?>" alt="" title="" class="img-fluid">
          </div>
          <?php 
              } 
            }
          ?>
       </div>
     </div>
     
      <div class="after-slides-construc">
        <div class="content text-center">
          <div class="row justify-content-center">
            <div class="col-md-6">
              <div class="owl-carousel screenshot_slider_sync owl-theme">
              <?php 
              $b = 1;
              $milestoneHome = get_field('milestone');
              if( $milestoneHome ) {
                foreach( $milestoneHome as $milestoneHomex ) { 
                ?> 
                <div class="item" data-hash="data-<?php echo $b++;?>">
                  <h2><?php echo $milestoneHomex['title']; ?> <span><?php echo $milestoneHomex['years']; ?></span></h2>
                  <p><?php echo $milestoneHomex['shortdesc']; ?></p>
                </div>
                <?php 
              } 
            }
          ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Constructions Section -->

  <section id="list-milestone" class="section">
    <div class="container" data-aos="fade-up">
      <div class="row">
      <?php 
      $clientHome = get_field('clients');
      if( $clientHome ) {
        foreach( $clientHome as $clientHomex ) { 
        ?> 
        <div class="block">
          <img src="<?php echo esc_url( $clientHomex['img']['url'] ); ?>" alt="" class="img-responsive">
          <div class="desc">
            <p><?php echo $clientHomex['shortdesc']; ?></p>
          </div>
          <div class="text-end"><a class="visit-site text-uppercase " href="<?php echo $clientHomex['link']; ?>" target=”_blank”>Visit site</a></div>
        </div>
        <?php 
              } 
            }
          ?>
      </div>
    </div>
  </section>

  <section id="our-companies" class="section">
    <div class="header-panel">
      <div class="container">
      <?php
  $ocSection = get_field('our_companies_title_section');  ?>
        <h1 class="text-uppercase title-panel"><?php echo $ocSection['title']; ?></h1>
      </div>
    </div>
    <div class="content-our-companies" data-aos="fade-up">
      <div class="row">
      <?php 
      $ourCompaniesHome = get_field('our_companies');
      if( $ourCompaniesHome ) {
        foreach( $ourCompaniesHome as $ourCompaniesHomex ) { 
        ?> 
        <div class="block col-md-6 px-0">
          <div class="img"><img src="<?php echo esc_url( $ourCompaniesHomex['img']['url'] ); ?>" alt="" class="img-fluid"></div>
          <div class="title"><a href="<?php echo $ourCompaniesHomex['link']; ?>" class="text-uppercase"><?php echo $ourCompaniesHomex['title']; ?></a></div>
        </div>
        <?php 
              } 
            }
          ?>
      </div>
    </div>
  </section>

<?php
  $newsHome = get_field('news_release');  ?>
  <section id="news" class="news-release">
    <div class="header-panel">
      <div class="container">
        <h1 class="text-uppercase title-panel"><?php echo $newsHome['title_section']; ?></h1>
      </div>
    </div>
    <div class="news-content-wrapper" >
      <div class="banner-wrapper position-relative">
          <div class="banner-img"><img src="<?php echo esc_url( $newsHome['img']['url'] ); ?>" alt="" class="img-fluid"></div>
          <div class="headline-wrapper position-absolute">
            <div class="container">
              <h1 class="text-uppercase title"><?php echo $newsHome['title']; ?></h1>
              <h2 class="subtitle"><?php echo $newsHome['area']; ?></h2>
              <div class="desc"><?php echo $newsHome['shortdesc']; ?></div>
              <div class="readmore"><a href="<?php echo $newsHome['link']; ?>" class="text-uppercase">read more</a></div>
            </div>
          </div>
        </div>
      <div class="news-content py-5" data-aos="fade-up">
        <div class="container">
          <div class="row">
              <?php
              $args = array(
                'post_type' => 'news_list',
                'post_status' => 'publish',
                'category_name' => 'news',
                'posts_per_page' => 8,
            );
            $arr_posts = new WP_Query( $args );
              
            if ( $arr_posts->have_posts() ) :
              
                while ( $arr_posts->have_posts() ) :
                    $arr_posts->the_post();
                    ?>
                    <div class="block col-md-3">
                       <div class="img">
                           <a class="visit-site text-uppercase " href="<?php the_permalink(); ?>" >
                        <?php
                        if ( has_post_thumbnail() ) :
                            the_post_thumbnail();
                        endif;
                        ?>
                            </a>
                        </div>
                        <div class="desc">
                            <?php echo excerpt(20); ?>
                        </div>
                        <div class="text-end"><a class="visit-site text-uppercase " href="<?php the_permalink(); ?>" >Visit site</a></div>
                    </div>
                    <?php
                endwhile;
            endif;
            ?>
              
          </div>
        </div>
        
      </div>
    </div>
  </section>

 
<?php get_footer(); ?>  