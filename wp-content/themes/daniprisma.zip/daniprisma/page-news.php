<?php get_header();?>
<?php /* Template Name: News Template */ ?>
<?php
  $newsPage = get_field('column');  ?>
  <section id="news-page" class="news-release p-0">
    <div class="news-content-wrapper news-page" >
      <div class="banner-wrapper position-relative">
        <div class="banner-img"><img src="<?php echo esc_url( $newsPage['img']['url'] ); ?>" alt="" class="img-fluid"></div>
        <div class="headline-wrapper position-absolute">
          <div class="container">
            <h1 class="text-uppercase title"><?php echo $newsPage['headline']; ?></h1>
            <h2 class="subtitle"><?php echo $newsPage['area']; ?></h2>
          </div>
        </div>
      </div>
      <div class="news-content py-5" data-aos="fade-up">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-5">
                        <div class="sliders-wrapper">
                            <div class="owl-carouselx owl-theme owl-carousel">
                            <?php 
                              $newsSliders = get_field('slider_news');
                              if( $newsSliders ) {
                                foreach( $newsSliders as $newsSlidersx ) { 
                            ?> 
                                <div class="item"><img src="<?php echo esc_url( $newsSlidersx['img']['url'] ); ?>" alt="" class="img-fluid"></div>
                                <?php 
                                  } 
                                }
                              ?> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="page-desc">
                            <?php the_content();?>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>

    
<?php get_footer();?>    