<?php get_header();?>

<?php /* Template Name: About Template */ ?>
<?php
  $about1 = get_field('about_us');  ?>
  <section id="about-page" style="background-image: url(<?php echo esc_url( $about1['img']['url'] ); ?>)">
    <div class="text-column" data-aos="fade-up">
      <h1 class="title text-white text-uppercase"><?php echo $about1['title']; ?></h1>
    </div>
  </section>
  <section id="about-content-page" class="section">
    <div class="container pb-5" data-aos="fade-up">
      <div class="row justify-content-center pb-5 mb-5">
        <div class="col-md-9">
          <div class="row">
          <?php 
          $sCreatorsFB = get_field('people');
          if( $sCreatorsFB ) {
            foreach( $sCreatorsFB as $sCreatorsFBx ) { 
            ?> 
            <div class="col-md-4 position-relative mb-5">
              <div class="block">
                <div class="img"><img src="<?php echo esc_url( $sCreatorsFBx['img']['url'] ); ?>" alt="" class="img-fluid"></div>
                <div class="name pt-3"><?php echo $sCreatorsFBx['name']; ?></div>
                <div class="jobtitle"><?php echo $sCreatorsFBx['job_title']; ?></div>
                <div class="shortdesc mt-2">
                  <?php echo $sCreatorsFBx['shortdesc']; ?>
                </div>
              </div>
            </div>
            <?php 
              } 
            }
          ?>
          </div>
        </div>
        
      </div>
    </div>
  </section>
    
<?php get_footer();?>  