<?php get_header();?>
  <section id="news-page" class="news-release p-0">
    <div class="news-content-wrapper news-page" >
      <div class="banner-wrapper position-relative">
        <div class="banner-img">
            <?php
              if ( has_post_thumbnail() ) :
                  the_post_thumbnail('full',array( 'class'  => 'img-fluid' ));
              endif;
              ?>
        </div>
      </div>
      <div class="news-content py-5" data-aos="fade-up">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        // Start the loop.
                        while ( have_posts() ) : the_post(); ?>
                        <div class="page-desc">
                            <h4 class="mb-4"><?php the_title();?></h4>
                            <?php the_content();?> 
                        <?php // End the loop.
                                endwhile;
                                ?>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>

    
<?php get_footer();?>    