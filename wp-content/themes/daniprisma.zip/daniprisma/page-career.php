<?php get_header();?>

<?php /* Template Name: Career Template */ ?>
<?php
  $careerPage = get_field('column_list');  ?>
  <section id="career-page" style="background-image: url(<?php echo esc_url( $careerPage['img']['url'] ); ?>)">
    <div class="text-column" data-aos="fade-up">
      <h1 class="title text-white text-uppercase"><?php the_title(); ?></h1>
    </div>
  </section>
  <section id="career-content-page" class="section">
    <div class="container" data-aos="fade-up">
      <div class="row justify-content-center">
        <div class="col-md-9">
          <div class="row">
            <div class="col mb-4">
              <h2 class="title-page position-relative"><?php echo $careerPage['lable_text_top']; ?></h2>
            </div>
          </div>
          <div class="lable-top bg-white px-4 py-3">
            <div class="row">
              <div class="col-6">
                <h2 class="title text-uppercase mb-0"><?php echo $careerPage['table_left']; ?></h2>
              </div>
              <div class="col-3">
                <h2 class="title text-uppercase mb-0"><?php echo $careerPage['table_center']; ?></h2>
              </div>
              <div class="col-3">
                <h2 class="title text-uppercase mb-0"><?php echo $careerPage['table_right']; ?></h2>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12">
            <?php
              if(pll_current_language() == 'en'){
              echo do_shortcode('[ajax_load_more loading_style="green" container_type="div" acf="true" acf_post_id="138" acf_field_type="repeater" acf_field_name="column_list_job" post_type="job" images_loaded="true" scroll="false" posts_per_page="2"]');
              }else{
              echo do_shortcode('[ajax_load_more loading_style="green" container_type="div" acf="true" acf_post_id="175" acf_field_type="repeater" acf_field_name="column_list_job" post_type="job" images_loaded="true" scroll="false" posts_per_page="2"]');
              }
            ?>
            </div>
			</div>
        </div>
        
      </div>
    </div>
  </section>

	<script>
	window.almComplete = function(alm){
		document.querySelectorAll('.modal.fade').forEach(function(item){
			document.body.appendChild(item);
		});
	};

	window.almDone = function(){
		document.querySelectorAll('.modal.fade').forEach(function(item){
			document.body.appendChild(item);
		});
	};
</script>

<?php get_footer();?>